﻿using ImmRequest.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImmRequest.WebApi.Models
{
    public class StatusModel
    {
        public RequestStatus Status { get; set; }
    }
}
